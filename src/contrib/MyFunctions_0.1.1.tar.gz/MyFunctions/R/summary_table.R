#' Creates a summary table from data.frame() and coppies to clipboard
#'
#' @param x A dataframe to copy
#' @param groupBy  List of columns to group by
#' @param column column to aggragate
#' @param ... Any Other Parameters Supported by write.table
#' @return data.frame()
#' @examples
#' myDataFrame <-data.frame()
#' write.clipboard(myDataFrame)
#' @export
summary_table <- function(x,groupBy,column){
  temp<-ddply(data, groupBy, function(x) summary(x[,column]))
  write.clipboard(temp)
  return(temp)
}
