#' Copies DataFrame to Clipboard
#'
#' @param x A dataframe to copy
#' @param row.names Include Row Names
#' @param col.names Include Column Names
#' @param ... Any Other Parameters Supported by write.table
#' @return Nothing Data is Coppied to Clipboard
#' @examples
#' myDataFrame <-data.frame()
#' write.clipboard(myDataFrame)
#' @export
write.clipboard <- function(x,row.names=FALSE,col.names=TRUE,...) {
  write.table(x,"clipboard",sep="\t",row.names=row.names,col.names=col.names,...)
}
#' reads DataFrame from Clipboard
#'
#' @return data.frame()
#' @examples
#' read.clipboard()
#' @export
read.clipboard <- function(header=TRUE,...) {
  read.table("clipboard",sep="\t",header=header,...)
}
