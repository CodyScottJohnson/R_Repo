# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'


Imagine_CheckGrowth <- function(file) {
  test <- readLines(file(paste('C:/CloudData/StudentDocuments/',as.character(file),sep='')))
  value <-'Unknown Value'
  #ERROR HANDLING
  possibleError <- tryCatch(
    Json_Doc<-fromJSON(test),
    error=function(e) e
  )
  if(!inherits(possibleError, "error")){
    #REAL WORK
    rm(test)
    StudentID <- Json_Doc[['_id']]
    if(!("StudentMetaData" %in% names(Json_Doc)))
    {
      value <-'No MetaData'
    }
    l1<-Json_Doc[['StudentMetadata']]
    if(!("GrowthSettings" %in% names(l1)))
    {
      value <-'No Growth Setting'
    }
    else{
      l2<-data.frame(l1[['GrowthSettings']])
      names(l1)
      l2$StudentID <-StudentID
      nms <- c('OptIn','StudentID')
      nms2 <- names(l2)

      if("OptIn" %in% names(l2))
      {
        l3<-l2[,intersect(nms,nms2)]
        value <- l3$OptIn
      }
    }
    return(value)
  }
  else{
    return('oops')
  }

}

