Imagine_CheckLexile <- function(file) {
  test <- readLines(file(paste('C:/CloudData/StudentDocuments/',as.character(file),sep='')))
  value <-'Unknown Value'
  #ERROR HANDLING
  possibleError <- tryCatch(
    Json_Doc<-fromJSON(test),
    error=function(e) e
  )
  if(!inherits(possibleError, "error")){
    #REAL WORK
    rm(test)
    StudentID <- Json_Doc[['_id']]
    if(!("StudentMetaData" %in% names(Json_Doc)))
    {
      value <-'No MetaData'
    }
    l1<-Json_Doc[['StudentMetadata']]
    if(!("LexileSettings" %in% names(l1)))
    {
      value <-'No Growth Setting'
    }
    else{
      l2<-data.frame(l1[['LexileSettings']])
      names(l1)
      l2$StudentID <-StudentID
      nms <- c('OptIn','StudentID')
      nms2 <- names(l2)

      if("OptIn" %in% names(l2))
      {
        l3<-l2[,intersect(nms,nms2)]
        value <- l3$OptIn
      }
    }
    return(value)
  }
  else{
    return('oops')
  }

}

